# firefox-electron-blue-theme
Single theme addon build with Firefox Color
